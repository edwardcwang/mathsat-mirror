package mathsat;

public interface TerminationTest {
    public int callback();
}
